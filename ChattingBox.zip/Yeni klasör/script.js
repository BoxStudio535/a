document.getElementById('signUpForm').addEventListener('submit', function(e) {
    e.preventDefault();

    let userId = Math.floor(Math.random() * 9000000000) + 1000000000;
    let userData = {
        username: document.getElementById('username').value,
        email: document.getElementById('email').value,
        password: document.getElementById('password').value,
        id: userId
    };

    localStorage.setItem('user', JSON.stringify(userData));
    alert('Your User ID is: ' + userId);

    // Show the main app section and hide the sign-up form
    document.getElementById('signUpSection').style.display = 'none';
    document.getElementById('appSection').style.display = 'block';
    document.getElementById('userIdDisplay').innerText = userId;
});

// Toggle dark mode
document.getElementById('darkModeToggle').addEventListener('change', function() {
    document.body.classList.toggle('dark-mode');
});

// Add friend functionality
document.getElementById('addFriendButton').addEventListener('click', function() {
    let friendId = prompt('Enter the 10-digit ID of your friend:');
    if (friendId && friendId.length === 10) {
        let li = document.createElement('li');
        li.textContent = 'Friend ' + friendId;
        li.dataset.friendId = friendId;
        document.getElementById('friendListUl').appendChild(li);

        li.addEventListener('click', function() {
            openChat(friendId);
        });
    } else {
        alert('Invalid ID. Please try again.');
    }
});

// Show settings
document.getElementById('settingsButton').addEventListener('click', function() {
    document.getElementById('settingsSection').style.display = 'block';
    document.getElementById('friendsList').style.display = 'none';
    document.getElementById('chatSection').style.display = 'none';
});

// Back to chat from settings
document.getElementById('backToChatButton').addEventListener('click', function() {
    document.getElementById('settingsSection').style.display = 'none';
    document.getElementById('friendsList').style.display = 'block';
});

// Sending messages
document.getElementById('sendButton').addEventListener('click', function() {
    let messageInput = document.getElementById('messageInput');
    let messageText = messageInput.value.trim();
    if (messageText) {
        sendMessage(messageText);
        messageInput.value = '';
    }
});

// Open chat with a friend
function openChat(friendId) {
    document.getElementById('chatSection').style.display = 'block';
    document.getElementById('messageInput').disabled = false;
    document.getElementById('sendButton').disabled = false;

    // Clear existing messages
    document.getElementById('messages').innerHTML = '';

    // Retrieve existing messages from localStorage
    let storedMessages = JSON.parse(localStorage.getItem('messages')) || {};
    if (storedMessages[friendId]) {
        storedMessages[friendId].forEach(msg => displayMessage(msg.text, msg.timestamp));
    }

    document.getElementById('sendButton').dataset.friendId = friendId;
}

function sendMessage(text) {
    let friendId = document.getElementById('sendButton').dataset.friendId;
    let timestamp = new Date().toLocaleString();

    let messageData = { text: text, timestamp: timestamp };
    displayMessage(text, timestamp);

    // Save the message to localStorage
    let storedMessages = JSON.parse(localStorage.getItem('messages')) || {};
    if (!storedMessages[friendId]) {
        storedMessages[friendId] = [];
    }
    storedMessages[friendId].push(messageData);
    localStorage.setItem('messages', JSON.stringify(storedMessages));
}

function displayMessage(text, timestamp) {
    let messageElement = document.createElement('div');
    messageElement.classList.add('message');
    messageElement.innerHTML = `${text}<div class="timestamp">${timestamp}</div>`;
    document.getElementById('messages').appendChild(messageElement);
}
